<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
          "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
  <HEAD>
    <TITLE>HOTELE: usuwanie bazy danych</TITLE>
    <META http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  </HEAD>

<BODY>

<H1>HOTELE - usuwanie bazy danych</H1>
<?php

$nazwabazydanych = "dbhotele";

$link = mysql_connect("localhost", "", "")
    or die("B��D: nie mo�na si� po��czy� z serverem mySQL");

$result = mysql_query("DROP DATABASE $nazwabazydanych")
    or die("B��D: nie mo�na usun�� bazy danych");

echo "<P>Powiod�o si�!</P>";

mysql_close($link);
?>
</TABLE>

</BODY>
</HTML>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
          "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
  <HEAD>
    <TITLE>HOTELE: tworzenie bazy danych</TITLE>
    <META http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  </HEAD>

<BODY>

<H1>HOTELE - tworzenie bazy danych</H1>

<?php

$nazwabazydanych = "dbhotele";

$link = mysql_connect("localhost", "", "")
    or die("B��D: nie mo�na si� po��czy� z serverem mySQL");

$result = mysql_query("CREATE DATABASE $nazwabazydanych")
    or die("B��D: nie mo�na utworzy� bazy danych");

$result = mysql_db_query($nazwabazydanych, "
CREATE TABLE thotele (
    nazwa VARCHAR (150) not null ,
    kod   VARCHAR (15) not null ,
    miejscowosc  VARCHAR (50) not null ,
    ulica VARCHAR (150) not null ,
    numerdomu VARCHAR (15) not null ,
    telefon VARCHAR (15) not null ,
    www  VARCHAR (100) not null ,
    PRIMARY KEY (nazwa,miejscowosc,telefon),
    INDEX (nazwa,miejscowosc,telefon)
)
")
    or die("B��D: nie mo�na utworzy� tabeli");

echo "<P>Powiod�o si�!</P>";

mysql_close($link);
?>
</TABLE>

</BODY>
</HTML>

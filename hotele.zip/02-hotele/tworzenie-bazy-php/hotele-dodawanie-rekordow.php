<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
          "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
  <HEAD>
    <TITLE>HOTELE: dodawanie rekord�w</TITLE>
    <META http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  </HEAD>

<BODY>

<H1>HOTELE - dodawanie rekord�w</H1>

<H2>Do��czanie rekord�w do bazy danych:</H2>

<TABLE border="1">
<TR>
  <TD>
    <STRONG>Nazwa</STRONG>
  </TD>
  <TD>
    <STRONG>Kod</STRONG>
  </TD>
  <TD>
    <STRONG>miejscowo��</STRONG>
  </TD>
  <TD>
    <STRONG>Ulica</STRONG>
  </TD>
  <TD>
    <STRONG>Numer domu</STRONG>
  </TD>
  <TD>
    <STRONG>telefon</STRONG>
  </TD>
  <TD>
    <STRONG>www</STRONG>
  </TD>

</TR>


<?php
$nazwabazydanych = "dbhotele";

$link = mysql_connect("localhost", "", "")
    or die("B��D: nie mo�na si� po��czy� z serverem mySQL");

mysql_select_db($nazwabazydanych)
    or die("B��D: wyb�r bazy danych");

$plik  = file('hotele.txt');
$plikc = count($plik);
for ($i = 0; $i < $plikc; $i++) {
    $linia    = explode('|', trim($plik[$i]));
    $linia[0] = strtoupper($linia[0]);


    $query = "INSERT INTO thotele(nazwa, kod, miejscowosc, ulica, numerdomu, telefon, www)" .
             " VALUES ('$linia[0]', '$linia[1]', '$linia[2]', '$linia[3]',
             '$linia[4]', '$linia[5]', '$linia[6]')";
    $result = mysql_query($query)
        or die("Query failed");


    $liniac   = count($linia);
    for ($j = 0; $j < $liniac; $j++) {
        if ($linia[$j] == '') {
            $linia[$j] = '&nbsp;';
        }
    }

?>
<TR>
<TD><?php echo $linia[0]; ?></TD>
<TD><?php echo $linia[1]; ?></TD>
<TD><?php echo $linia[2]; ?></TD>
<TD><?php echo $linia[3]; ?></TD>
<TD><?php echo $linia[4]; ?></TD>
<TD><?php echo $linia[5]; ?></TD>
<TD><?php echo $linia[6]; ?></TD>

</TR>
<?php
}//for ($i = ...

mysql_close($link);
?>

</TABLE>

</BODY>
</HTML>

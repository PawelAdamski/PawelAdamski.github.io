<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
          "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
  <HEAD>
    <TITLE>HOTELE</TITLE>
    <META http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
    <LINK rel="stylesheet" href="style.css" type="text/css">
  </HEAD>

<BODY>

<H1>HOTELE</H1>

<?php

$nazwabazydanych = "dbhotele";

$link = mysql_connect("localhost", "reader", "")
    or die("B��D: nie mo�na si� po��czy� z serverem mySQL");

mysql_select_db ($nazwabazydanych)
    or die("B��D: wyb�r bazy danych");

$zapytanie = "SELECT * FROM thotele";

$result = mysql_query($zapytanie);
while ($wiersz = mysql_fetch_array($result)) {
    echo '<TABLE class="client">';
    if (trim($wiersz['nazwa']) != "") {
        echo "<TR><TD class=\"nazwa\">{$wiersz['nazwa']}</TD></TR>";
    }
    echo "<TR><TD>{$wiersz['kod']} {$wiersz['miejscowosc']}</TD></TR>";
    echo "<TR><TD>{$wiersz['ulica']} {$wiersz['numerdomu']} </TD></TR>";
    echo "<TR><TD>tel. {$wiersz['telefon']}</TD></TR>";
    echo "<TR><TD><A href=\"{$wiersz['www']}\">{$wiersz['www']}</A></TD></TR>";
    echo '</TABLE>';
}

mysql_close($link);
?>

</BODY>
</HTML>
